// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAh601EnTyI5Nfsgrj5d_Af1UCoxCOptGM",
  authDomain: "localbazaar24.firebaseapp.com",
  projectId: "localbazaar24",
  storageBucket: "localbazaar24.firebasestorage.app",
  messagingSenderId: "78938865637",
  appId: "1:78938865637:web:caa3139f97f23493b0390c",
  measurementId: "G-FY43RK9S87"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };
