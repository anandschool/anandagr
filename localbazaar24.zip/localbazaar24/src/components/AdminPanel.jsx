import React, { useState } from "react";
import { db } from "../firebase";
import { collection, addDoc } from "firebase/firestore";

export default function AdminPanel() {
  const [product, setProduct] = useState({ brand: "", model: "", price: "", image: "" });
  const [delivery, setDelivery] = useState({ pincode: "", date: "" });

  const handleAddProduct = async () => {
    try {
      await addDoc(collection(db, "products"), product);
      alert("Product added");
    } catch (e) {
      alert("Error adding product");
    }
  };

  const handleAddDelivery = async () => {
    try {
      await addDoc(collection(db, "deliveries"), delivery);
      alert("Delivery date added");
    } catch (e) {
      alert("Error adding delivery date");
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">Admin Panel</h2>
      <div className="mb-4">
        <input placeholder="Brand" className="border p-1 m-1" onChange={e => setProduct({ ...product, brand: e.target.value })} />
        <input placeholder="Model" className="border p-1 m-1" onChange={e => setProduct({ ...product, model: e.target.value })} />
        <input placeholder="Price" className="border p-1 m-1" onChange={e => setProduct({ ...product, price: e.target.value })} />
        <input placeholder="Image URL" className="border p-1 m-1" onChange={e => setProduct({ ...product, image: e.target.value })} />
        <button onClick={handleAddProduct} className="bg-blue-500 text-white px-2 py-1 rounded">Add Product</button>
      </div>

      <div>
        <input placeholder="Pincode" className="border p-1 m-1" onChange={e => setDelivery({ ...delivery, pincode: e.target.value })} />
        <input type="date" className="border p-1 m-1" onChange={e => setDelivery({ ...delivery, date: e.target.value })} />
        <button onClick={handleAddDelivery} className="bg-green-500 text-white px-2 py-1 rounded">Add Delivery Date</button>
      </div>
    </div>
  );
}
