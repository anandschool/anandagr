import { auth } from "../firebase";
import { signOut } from "firebase/auth";
import { useAuthState } from "react-firebase-hooks/auth";
import { Link } from "react-router-dom";

export default function Header() {
  const [user] = useAuthState(auth);

  return (
    <div className="flex justify-between items-center p-4 shadow bg-white">
      <Link to="/" className="text-2xl font-bold text-blue-600">Localbazaar24</Link>
      <div className="space-x-4">
        {user ? (
          <>
            <span>{user.email}</span>
            <button onClick={() => signOut(auth)} className="bg-red-500 text-white px-3 py-1 rounded">Logout</button>
          </>
        ) : (
          <>
            <Link to="/login" className="bg-blue-500 text-white px-3 py-1 rounded">Login</Link>
            <Link to="/register" className="bg-green-500 text-white px-3 py-1 rounded">Register</Link>
          </>
        )}
      </div>
    </div>
  );
}
