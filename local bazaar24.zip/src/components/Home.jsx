export default function Home() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-bold text-blue-600">Welcome to Localbazaar24</h1>
      <p className="text-gray-600">Your trusted platform for refurbished premium mobile phones.</p>
    </div>
  );
}